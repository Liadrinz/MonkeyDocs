package com.monkey.ot;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.monkey.entity.Delta;

import java.util.*;

@Deprecated
public class Operation {

}