const serverConfig = {
    server: {
        host: '0.0.0.0',
        port: 8088
    },
    redis: {
        host: '175.24.45.175',
        port: 6379,
        auth: '123456'
    },
    biz: {
        host: 'monkeydoc.liadrinz.cn'
    }
}

module.exports = serverConfig;